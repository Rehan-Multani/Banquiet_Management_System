// import express from "express";
// import { superAdminLogin } from "../../controllers/superAdminController/superAdminController.js";

// const router = express.Router();

// // checking is user super Admin or not function

// // routers
// router.post("/login", superAdminLogin);

// export default router;
